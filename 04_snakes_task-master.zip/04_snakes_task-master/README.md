# Змейка по сети
Описание формата протокола в файле src/main/protobuf/snakes.proto.

Текстовое описание игры в файле snakes_task.txt.

Вариант раскладки интерфейса в файле snakes_interface.png.

